package com.leucine.cda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CdaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
