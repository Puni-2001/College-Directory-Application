package com.leucine.cda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CdaBackendApplication.class, args);
	}

}
