package com.leucine.cda.dto;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class EnrollmentDTO {
    private Long id;
    private Long studentId;
    private Long courseId;
    // Getters and Setters
}
