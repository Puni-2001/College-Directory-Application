package com.leucine.cda.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdministratorProfileDTO {
    private Long userId;
    private String photo;
    private Long departmentId;
    // Getters and Setters
}
